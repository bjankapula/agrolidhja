# agrolidhja

A Pen created on CodePen.

Original URL: [https://codepen.io/Bianka-Pula/pen/JooEePL](https://codepen.io/Bianka-Pula/pen/JooEePL).

Lidhja  digitale midis fermerit dhe tregtarit