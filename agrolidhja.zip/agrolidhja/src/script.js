function showDashboard(role = "fermer") {
  let emri, mbiemri, email, tel, nipt = "", vendndodhja;

  if (role === "fermer") {
    emri = document.querySelector('#fermere input[placeholder="Emri"]').value;
    mbiemri = document.querySelector('#fermere input[placeholder="Mbiemri"]').value;
    email = document.querySelector('#fermere input[placeholder="Email-i"]').value;
    tel = document.querySelector('#fermere input[placeholder="Numri i telefonit"]').value;
    nipt = document.querySelector('#fermere input[placeholder="NIPT"]').value;
    vendndodhja = document.querySelector('#fermere input[list="vendndodhjet"]').value;
    document.getElementById('fermerContent').style.display = "block";
    document.getElementById('niptField').style.display = "list-item";
  } else {
    emri = document.querySelector('#tregtare input[placeholder="Emri"]').value;
    mbiemri = document.querySelector('#tregtare input[placeholder="Mbiemri"]').value;
    email = document.querySelector('#tregtare input[placeholder="Email-i"]').value;
    tel = document.querySelector('#tregtare input[placeholder="Numri i telefonit"]').value;
    vendndodhja = document.querySelector('#tregtare input[list="vendndodhjet"]').value;
    document.getElementById('fermerContent').style.display = "none";
    document.getElementById('niptField').style.display = "none";
  }

  document.getElementById('dashName').innerText = emri;
  document.getElementById('dashEmri').innerText = emri;
  document.getElementById('dashMbiemri').innerText = mbiemri;
  document.getElementById('dashEmail').innerText = email;
  document.getElementById('dashTel').innerText = tel;
  document.getElementById('dashNipt').innerText = nipt;
  document.getElementById('dashVendndodhja').innerText = vendndodhja;

  showSection('dashboard');
}

function addProduct() {
  const name = document.getElementById('productName').value;
  const price = document.getElementById('productPrice').value;
  const list = document.getElementById('myProducts');

  const li = document.createElement('li');
  li.textContent = `${name} - ${price} Lek/kg`;
  list.appendChild(li);

  document.getElementById('productName').value = '';
  document.getElementById('productPrice').value = '';
}
function showDashboard(role = "fermer") {
  showSection('dashboard');
  
  if (role === "fermer") {
    const emri = document.querySelector('#fermere input[placeholder="Emri"]').value;
    const mbiemri = document.querySelector('#fermere input[placeholder="Mbiemri"]').value;
    const email = document.querySelector('#fermere input[placeholder="Email-i"]').value;
    const tel = document.querySelector('#fermere input[placeholder="Numri i telefonit"]').value;
    const nipt = document.querySelector('#fermere input[placeholder="NIPT"]').value;
    const vendndodhja = document.querySelector('#fermere input[list="vendndodhjet"]').value;

    document.getElementById('dashName').innerText = emri;
    document.getElementById('dashEmri').innerText = emri;
    document.getElementById('dashMbiemri').innerText = mbiemri;
    document.getElementById('dashEmail').innerText = email;
    document.getElementById('dashTel').innerText = tel;
    document.getElementById('dashNipt').innerText = nipt;
    document.getElementById('dashVendndodhja').innerText = vendndodhja;

    document.getElementById('fermerContent').style.display = "block";
    document.getElementById('traderContent').style.display = "none";
  } else {
    const emri = document.querySelector('#tregtare input[placeholder="Emri"]').value;
    const mbiemri = document.querySelector('#tregtare input[placeholder="Mbiemri"]').value;
    const email = document.querySelector('#tregtare input[placeholder="Email-i"]').value;
    const tel = document.querySelector('#tregtare input[placeholder="Numri i telefonit"]').value;
    const vendndodhja = document.querySelector('#tregtare input[list="vendndodhjet"]').value;

    document.getElementById('traderEmri').innerText = emri;
    document.getElementById('traderMbiemri').innerText = mbiemri;
    document.getElementById('traderEmail').innerText = email;
    document.getElementById('traderTel').innerText = tel;
    document.getElementById('traderVendndodhja').innerText = vendndodhja;

    document.getElementById('fermerContent').style.display = "none";
    document.getElementById('traderContent').style.display = "block";
  }
}
function addToCart() {
  const product = document.getElementById('cartProduct').value;
  const quantity = document.getElementById('cartQuantity').value;

  const li = document.createElement('li');
  li.textContent = `${product} - ${quantity} kg`;
  document.getElementById('cartList').appendChild(li);

  document.getElementById('cartProduct').value = '';
  document.getElementById('cartQuantity').value = '';
}
